insert into DrivingRecords values(1,"2020-10-9","medium",7,681162505);
insert into DrivingRecords values(2,"2020-4-8","medium",8,513207677);
